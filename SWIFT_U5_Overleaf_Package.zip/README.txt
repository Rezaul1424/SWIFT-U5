SWIFT-U5 OVERLEAF SUBMISSION PACKAGE
=====================================
Title: SWIFT-U5: A Survey-Weighted and Temporally Calibrated Machine Learning Framework for Population-Level Child Mortality Risk Stratification in Bangladesh
Authors: Md. Rafiul Azam Chowdhury, Rezaul Mursalin Khan, Fatema Tuz Zohura Rifa, Tanjim Ahmed Irfad, Arafat Hussain Nahid, Ohidujjaman
Affiliation: Department of Computer Science and Engineering, United International University, Dhaka 1212, Bangladesh

PACKAGE CONTENTS:
1. main.tex          - Primary LaTeX document (configured for Overleaf auto-compilation)
2. manuscript.tex    - Identical copy of main.tex
3. cas-refs.bib      - Comprehensive BibTeX database (54 entries)
4. figures/          - The 7 high-resolution figures referenced in the manuscript
5. tables/           - Standalone LaTeX and CSV tables (Tables 1 through 7 and audit tables)
6. README.txt        - Overleaf setup and compilation instructions

HOW TO COMPILE ON OVERLEAF:
1. Go to https://www.overleaf.com and log in to your account.
2. Click 'New Project' -> 'Upload Project'.
3. Select this zip file: SWIFT_U5_Overleaf_Package.zip.
4. Overleaf will extract the project and automatically select 'main.tex' as the root file.
5. In Overleaf Menu (top left):
   - Compiler: pdfLaTeX
   - TeX Live version: 2023 or 2024 (recommended)
   - Main document: main.tex (or manuscript.tex)
6. Click 'Recompile'. The PDF will compile cleanly!
