SWIFT-U5 OVERLEAF SUBMISSION PACKAGE
=====================================
Title: Survey-Weighted and Temporally Validated Risk Modeling for Under-Five Mortality Using Bangladesh DHS Data
Authors: Md. Rafiul Azam Chowdhury, Rezaul Mursalin Khan, Fatema Tuz Zohura Rifa, Tanjim Ahmed Irfad, Arafat Hussain Nahid, Ohidujjaman

PACKAGE CONTENTS:
1. main.tex          - Primary LaTeX document (configured for Overleaf auto-compilation)
2. manuscript.tex    - Direct copy of the primary document
3. cas-refs.bib      - Comprehensive BibTeX database (54 entries)
4. figures/          - High-resolution (300 DPI) publication figures (Figures 1 to 7)

HOW TO COMPILE ON OVERLEAF:
1. Go to https://www.overleaf.com and log into your account.
2. Click "New Project" -> "Upload Project".
3. Select this zip file: SWIFT_U5_Overleaf_Package.zip.
4. Overleaf will extract the project and automatically select "main.tex" as the root file.
5. In Overleaf Menu (top left):
   - Compiler: pdfLaTeX
   - TeX Live version: 2023 or 2024
6. Click "Recompile". The PDF will compile cleanly with all 54 references and enlarged figures!
